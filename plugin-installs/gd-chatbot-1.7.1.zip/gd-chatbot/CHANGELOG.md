# Changelog

All notable changes to the GD Chatbot plugin will be documented in this file.

## [1.7.1] - 2026-01-10

### Created
- Initial release based on gd-claude-chatbot v1.7.1 (last stable version)
- Forked from gd-claude-chatbot to create standalone plugin

### Changed
- Plugin name changed from "GD Claude Chatbot" to "GD Chatbot"
- Text domain changed from `gd-claude-chatbot` to `gd-chatbot`
- Package references updated from `GD_Claude_Chatbot` to `GD_Chatbot`
- Main class renamed from `GD_Claude_Chatbot` to `GD_Chatbot`
- Updated all function and hook references accordingly

### Added
- Comprehensive README.md with installation and usage instructions
- CLAUDE.md context file for AI development assistance
- Enhanced context files with current versions where 1.7.1 didn't have them
- Grateful Dead disambiguation guide (from current version)
- Additional interview and equipment documentation files

### Preserved
- All PHP class files from gd-claude-chatbot v1.7.1
- Complete CSS and JavaScript assets
- All historical .zip installation files (v1.3.0 through v1.9.5)
- Core functionality: Claude API, Tavily search, Pinecone integration
- Database schema and option structure
- Admin interface and settings
- Frontend themes (Professional and Psychedelic)
- Context files from v1.7.1
- Setlist search functionality
- Knowledge base integrations (Knowledgebase Loader, AI Power)

### Features Included
- Claude AI integration (Anthropic API)
- Streaming response support via SSE
- Tavily web search integration
- Pinecone vector database support
- WordPress Knowledgebase Loader integration
- AI Power plugin integration
- CSV-based setlist search (1965-1995)
- Customizable appearance and themes
- Conversation logging and history
- WordPress shortcode support: `[gd_chatbot]`
- Floating widget option
- Admin settings interface
- Connection testing for all APIs
- Configurable system prompts
- Multi-source context aggregation

### Technical Details
- WordPress 5.0+ compatibility
- PHP 7.4+ requirement
- Custom database table: `wp_gd_chatbot_conversations`
- Settings prefix: `gd_chatbot_`
- AJAX endpoints for chat and streaming
- Nonce-based security
- Proper sanitization and escaping

### Migration Notes
- Based on stable v1.7.1 codebase
- Can run alongside gd-claude-chatbot if needed
- Compatible with existing gd-claude-chatbot integrations
- Manual settings migration required if switching from gd-claude-chatbot

### File Structure
```
gd-chatbot/
├── gd-chatbot/
│   ├── gd-chatbot.php (v1.7.1)
│   ├── admin/
│   │   ├── class-admin-settings.php
│   │   ├── css/admin-styles.css
│   │   └── js/admin-scripts.js
│   ├── includes/
│   │   ├── class-aipower-integration.php
│   │   ├── class-chat-handler.php
│   │   ├── class-claude-api.php
│   │   ├── class-kb-integration.php
│   │   ├── class-pinecone-api.php
│   │   ├── class-setlist-search.php
│   │   └── class-tavily-api.php
│   ├── public/
│   │   ├── class-chatbot-public.php
│   │   ├── css/
│   │   │   ├── chatbot-styles.css
│   │   │   ├── gd-theme.css
│   │   │   └── professional-theme.css
│   │   └── js/chatbot.js
│   ├── context/
│   │   ├── Deadshows/ (CSV files 1965-1995)
│   │   ├── grateful_dead_disambiguation_guide.md
│   │   ├── grateful_dead_songs.csv
│   │   ├── grateful_dead_equipment.csv
│   │   └── [additional context files]
│   ├── uninstall.php
│   ├── README.md
│   └── CHANGELOG.md
└── plugin-installs/
    └── [21 historical .zip files from gd-claude-chatbot]
```

### Known Issues
- None at release (inherited stable v1.7.1 codebase)

### Dependencies
- WordPress 5.0+
- PHP 7.4+
- Anthropic Claude API key (required)
- Tavily API key (optional, for web search)
- Pinecone credentials (optional, for vector database)

### Credits
- Based on gd-claude-chatbot v1.7.1
- Developed by IT Influentials
- Original Grateful Dead context and knowledge base

---

## Future Releases

Future changes will be documented here as the plugin evolves beyond v1.7.1.

### Planned Features
- Multi-language support
- Enhanced analytics dashboard
- Additional theme options
- Extended API integration options
- Performance optimizations
- Additional knowledge base connectors

---

**Note**: This changelog follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) format and adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
