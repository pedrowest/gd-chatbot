
**URL:** http://www.deaddisc.com/GDFD_RHSongs.htm

---

Home | Index | Search	Introduction | What's New | Thanks | Links



Robert Hunter compositions

This page lists songs composed or co-composed by Robert Hunter that have been performed or recorded. Lyrics that have been published are also included. Some songs that have been registered but do not exist in the public domain in any format are also included.

The columns to the left indicate broadly who has performed or recorded the song. The 'others' section includes Jerry Garcia groups and the post-1995 Grateful Dead related groups.

For detailed information about a particular song select the 'info' button for that song.

For a list of covers of these compositions see the covers of Hunter compositions page.

Additions, corrections and comments are welcome

		


Related discography pages:

Robert Hunter recordings
Covers of Robert Hunter compositions
Robert Hunter books
Grateful Dead discography

Comfort | Dinosaurs | Roadhog
Robert Hunter solo
Robert Hunter & Bob Dylan
Robert Hunter & Larry Klein
Robert Hunter & Jim Lauderdale
Hart Valley Drifters




Go to songs starting with : A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P | Q | R | S | T | U | V | W | XYZ


1-9	
Played by
Robert Hunter

	
Played by
Grateful Dead

	
Played by
others


 7 Walkers	  -	  -	Yes
 8 Below Zero	  -	  -	Yes
 13 Clocks	  -	  -	Yes
 13 Horsemen	  -	  -	Yes
 13 Roses	Yes	  -	  -
 17 Pine Avenue	  -	  -	Yes
 20th Anniversary Rag	  -	  -	  -
 45th of November	  -	  -	Yes

A	
Played by
Robert Hunter

	
Played by
Grateful Dead

	
Played by
others


 Adventures In Love (aka Where Did You Go?)	Yes	  -	  -
 Again And Again	  -	  -	Yes
 Aim At The Heart	Yes	  -	  -
 Ain't No Doubt	  -	  -	  -
 Alabama Getaway	  -	Yes	Yes
 L'Alhambra	  -	  -	  -
 Alice Garbonzo Garbet	Yes	  -	  -
 Aliromba O Saro	  -	  -	Yes
 All My Bridges Burning	  -	  -	Yes
 All The Same	  -	  -	  -
 Alligator	  -	Yes	  -
 Alligator Alley	  -	  -	Yes
 Alligator Moon	  -	  -	  -
 Althea	  -	Yes	Yes
 Amagamalin Street	Yes	  -	  -
 American Spring	  -	  -	Yes
 And I Know You	  -	  -	  -
 Anthem For Bear	Yes	  -	  -
 Anybody's Guess	  -	  -	Yes
 Argentina	  -	  -	Yes